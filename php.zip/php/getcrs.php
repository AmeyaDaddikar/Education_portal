<!DOCTYPE html>
<html>
<head>
</head>
<body>
  <?php
  $q = $_GET['q'];
  // echo $q;
  $servername="localhost";
  $username="root";
  $password="PMARDV1";
  $dbname="education_portal";
  $dbname_fail="abcd";
 
  try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "Connected successfully!" ;
  }
  catch(PDOException $e) {
    echo "Couldn't Connect to Database " . $e->getMessage();
  }
  echo '<select id="course">' . '\n';
  echo '<option value="">--Select Course--</option>';
  $sql = "SELECT * FROM course WHERE course_id IN (SELECT course_id FROM college_course WHERE clg_id = (SELECT clg_id FROM college WHERE clg_name = '".$q."'))";
  $stmt = $conn->prepare($sql);
  $stmt->execute();
  $data = $stmt->fetchAll();
  foreach($data as $row) {
          echo "<option name=" . $row[course_name] . "value=" . $row[course_name] . ">" . $row[course_name] . "</option>" . "\n";
  }
  echo "</select>";
  $conn = null;
  ?>
</body>
</html>
