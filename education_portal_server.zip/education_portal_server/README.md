# Education_portal
An educational portal created for the summers INHERITANCE project.
